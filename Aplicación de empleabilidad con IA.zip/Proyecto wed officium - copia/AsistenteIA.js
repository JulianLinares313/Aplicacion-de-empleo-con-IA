// AsistenteIA.js - Asistente basado en Gemini API para Empleos del Llano

class AsistenteIA {
  constructor() {
    this.apiKey = 'AIzaSyAIYgMOsuA19PMsx0PvScF5VkzEtLQIo9Q';
    this.model = 'gemini-1.5-flash';
    this.apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent?key=${this.apiKey}`;
  }

  // Obtener contexto de ofertas desde la API
  async obtenerContextoOfertas() {
    try {
      const response = await fetch('http://localhost:3000/ofertas');
      const ofertas = await response.json();
      
      let contexto = 'OFERTAS DE EMPLEO DISPONIBLES EN EL LLANO:\n\n';
      ofertas.forEach((oferta, index) => {
        contexto += `${index + 1}. ${oferta.titulo} - ${oferta.empresa}\n`;
        contexto += `   Sector: ${oferta.sector}\n`;
        contexto += `   Ubicación: ${oferta.ubicacion}\n`;
        contexto += `   Salario: ${oferta.salario}\n`;
        contexto += `   Descripción: ${oferta.descripcion}\n\n`;
      });
      
      return contexto;
    } catch (error) {
      console.error('Error al obtener ofertas:', error);
      return 'Ofertas no disponibles en este momento.';
    }
  }

  // Obtener respuesta de Gemini
  async obtenerRespuesta(mensajeUsuario) {
    try {
      const contexto = await this.obtenerContextoOfertas();
      
      const systemPrompt = `Eres un asistente especializado de "Empleos del Llano" - una plataforma de empleo para el sector agropecuario, ganadería, agricultura, ecoturismo y conservación en Villavicencio y el Llano.

Tu función es:
1. Ayudar a usuarios a encontrar las mejores ofertas de empleo según sus habilidades
2. Responder preguntas sobre la plataforma y las ofertas disponibles
3. Dar información sobre sectores: Ganadería, Agricultura, Ecoturismo, Conservación, Acuicultura, Educación Ambiental

IMPORTANTE:
- Responde SOLO sobre ofertas de empleo y la plataforma
- Si preguntan sobre otros temas, di: "Disculpa, solo puedo ayudarte con información sobre ofertas de empleo en el Llano"
- Sé breve, amable y natural (máximo 3 párrafos)
- Responde en el mismo idioma del usuario

CONTEXTO DE OFERTAS:
${contexto}`;

      const requestBody = {
        contents: [{
          parts: [{
            text: systemPrompt + '\n\nPregunta del usuario: ' + mensajeUsuario
          }]
        }]
      };

      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`Error API: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.candidates && data.candidates.length > 0) {
        const content = data.candidates[0].content;
        if (content && content.parts && content.parts.length > 0) {
          return content.parts[0].text;
        }
      }
      
      return 'No pude procesar tu pregunta. Intenta de nuevo.';
    } catch (error) {
      console.error('Error al obtener respuesta de IA:', error);
      return `Error: ${error.message}. Por favor, intenta de nuevo más tarde.`;
    }
  }

  // Sintetizar texto a voz
  hablar(texto) {
    if ('speechSynthesis' in window) {
      // Cancelar cualquier síntesis anterior
      window.speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(texto);
      utterance.lang = 'es-ES';
      utterance.rate = 1;
      utterance.pitch = 1;
      
      window.speechSynthesis.speak(utterance);
    } else {
      console.log('TTS no disponible en este navegador');
    }
  }
}

// Exportar para uso global
window.AsistenteIA = AsistenteIA;
